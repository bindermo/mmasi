library(dplyr)
library(survival)

# TT2+TT3 gene expression data, clinical data, and survival outcomes obtained from GSE24080 [https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE24080]

rm(list=ls())
data <- read.table("GSE24080.txt", header = TRUE, sep = "\t")

# Calculate International Staging System (ISS) stage
    
data$albabn <- ifelse((data$albumin >= 3.5), 0, 1)
data$b2mgabn <- ifelse((data$b2mg >= 5.5), 1, 0)

data$iss[(data$albabn == 0 & data$b2mgabn == 1)] <- 1
data$iss[(data$albabn == 1 & data$b2mgabn == 0)] <- 1
data$iss[(data$albabn == 0 & data$b2mgabn == 0)] <- 0
data$iss[(data$albabn == 1 & data$b2mgabn == 1)] <- 2

# Calculate Adverse Stromal Interaction (ASI) score

score <- data[, c("FSTL1", "VCAN", "GADD45A", "FSCN1", "AKAP12", "IL6", "PTK2", "ARAP3", "AIM2", "ZEB2")]
decil <- apply(score, 2, ntile, 10)
decil[, 1:5] <- (10 - decil[, 1:5])
decil[, 6:10] <- (decil[, 6:10] - 1)

data$score <- rowSums(decil)
data$grp <- ifelse((data$score >= 50), 1, 0)
table(data$grp)

# Set up survival analysis (overall survival)

data$os_years <- (data$os_months / 12)
survival <- survfit(Surv(data$os_years, data$os_event == 1) ~ data$grp)

# Display results

table(data$iss)
tapply(data$score, data$grp, summary)
survival
survdiff(Surv(os_years, os_event == 1) ~ grp, data)

plot(survival)

cox <- coxph(Surv(os_years, os_event == 1) ~ iss + grp, data)
summary(cox)
stphtest <- cox.zph(cox)
stphtest

#
# Next dataset below
#

# MMRF IA16 gene expression data, clinical data, and survival outcomes obtained from the MMRF through the MMRF Researcher Gateway [https://research.themmrf.org]

rm(list=ls())
data <- read.table("MMRF_IA16.txt", header = TRUE, sep = "\t")

# Calculate Adverse Stromal Interaction (ASI) score

score <- data[, c("fstl1", "vcan", "gadd45a", "fscn1", "akap12", "il6", "ptk2", "arap3", "aim2", "zeb2")]
decil <- apply(score, 2, ntile, 10)
decil[, 1:5] <- (10 - decil[, 1:5])
decil[, 6:10] <- (decil[, 6:10] - 1)

data$score <- rowSums(decil)
data$grp <- ifelse((data$score >= 50), 1, 0)
table(data$grp)

# Set up survival analysis (overall survival)

data$os_years <- (data$os_days / 365.25)
survival <- survfit(Surv(data$os_years, data$os_censor == 0) ~ data$grp)

# Display results

table(data$iss)
tapply(data$score, data$grp, summary)
survival
survdiff(Surv(os_years, os_censor == 0) ~ grp, data)

plot(survival)

cox <- coxph(Surv(os_years, os_censor == 0) ~ iss + grp, data)
summary(cox)
stphtest <- cox.zph(cox)
stphtest

#
# Next dataset below
#

# IFM 2009 gene expression data, clinical data, and survival outcomes obtained from the IFM [https://www.myelome.fr]

rm(list=ls())
data <- read.table("IFM_2009.txt", header = TRUE, sep = "\t")

# Calculate Adverse Stromal Interaction (ASI) score

score <- data[, c("FSTL1", "VCAN", "GADD45A", "FSCN1", "AKAP12", "IL6", "PTK2", "ARAP3", "AIM2", "ZEB2")]
#
# Two patients are classified differently due to different precision / data handling (ntile) between Stata and R.
# This does not significantly influence the results or the overall conclusions.
#
decil <- apply(score, 2, ntile, 10)
#
#
decil[, 1:5] <- (10 - decil[, 1:5])
decil[, 6:10] <- (decil[, 6:10] - 1)

data$score <- rowSums(decil)
data$grp <- ifelse((data$score >= 50), 1, 0)
table(data$grp)

# Set up survival analysis (overall survival)

data$os_years <- (data$os_days / 365.25)
survival <- survfit(Surv(data$os_years, data$os_censor == 1) ~ data$grp)

# Display results

table(data$iss)
tapply(data$score, data$grp, summary)
survival
survdiff(Surv(os_years, os_censor == 1) ~ grp, data)

plot(survival)

cox <- coxph(Surv(os_years, os_censor == 1) ~ iss + grp, data)
summary(cox)
stphtest <- cox.zph(cox)
stphtest