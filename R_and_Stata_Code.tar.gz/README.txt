README for "Updated_R_and_Stata_Code.tar.gz"

1. System requirements

	All software dependencies and operating systems (including version numbers)
	- R v4.0.5 with packages dplyr v1.0.7 and survival v3.2-11
	
	or 
	
	- Stata v17.0
	
	Versions the software has been tested on
	- R v4.0.5, Stata v16.0 and v17.0
	
	Any required non-standard hardware
	- None
	

	
2. Installation guide

	Instructions
	- Unzip (gunzip) and untar (tar -xf) the "R_and_Stata_Code.tar.gz" file

	Typical install time on a "normal" desktop computer
	- Less than one minute


	
3. Demo

	Instructions to run on data
	- Execute ASI_R.R in R to analyze the three datasets after setting the correct working directory
	
	or
	
	- Execute ASI_Stata.do in Stata to analyze the three datasets after setting the correct working directory


	Expected output
	- International Staging System (ISS) stage distribution
	- Raw Adverse Stromal Interactions (ASI) score distribution
	- ASI classifier group assignments
	- Overall survival stratified by ASI classifier group assignment
	- Kaplan-Meier overall survival estimates (plot)
	- Log-rank test p-value comparing the two ASI groups in the plot
	- Output of an ISS-adjusted Cox proportional hazards overall survival regression model showing the independent prognostic significance of ASI
	- Information on the proportional hazards assumption of above Cox proportional hazards overall survival regression model


	Expected run time for demo on a "normal" desktop computer
	- Less than one minute



4. Instructions for use

	How to run the software on your data
	
	- Set up your own gene expression data analogous to the data in "GSE24080.txt", "MMRFIA16.txt", or "IFM2009.txt"
	- Change the filename in ASI_R.R and / or ASI_Stata.do accordingly
	- Proceed as described above:
	
	- Execute ASI_R.R in R to analyze the three datasets after setting the correct working directory
	
	or
	
	- Execute ASI_Stata.do in Stata to analyze the three datasets after setting the correct working directory